//三元表达式
void main() {
  int x;
  x = 10;
  x == 5 ? print x : print (x * 2);
}