void main(int x) {
  switch(x){
    case 1: print 10;
    case 2: print 20;
    case 3: print 30;
  }
}