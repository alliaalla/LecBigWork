void main(int n) {
    int a;
    a=10;
  	a+=n;
	print a;
  	a=10;
	a-=n;
  	print a;
	a=10;
  	a*=n;
	print a;
  	a=10;
  	a/=n;
  	print a;
  	a=10;
	a%=n;
  	print a;
}