// micro-C example 1
// int g ;
// int *h ;
// int i[2];
// int *j[2];
int (*k)[2];
int *(*l)[2];
void main(int n){
 int m;
 m = n;
//  m = g;
}
