int g ;
int h[3];
void main(int n){
n = 8;
}

