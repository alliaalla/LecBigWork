void main(int n) {
    n = 3;
}

void g(){}
