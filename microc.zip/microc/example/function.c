void main(int n) {
    g();
}

void g(){

}