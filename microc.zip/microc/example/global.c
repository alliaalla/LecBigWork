int* m;
int main(int n) {
	m = n + &m;
	//return m;
}
