
void main (int n){
int * p;
p = &n;
//*p = 1;
print *p;
// print &n;
}

