void main(int n ) {

    if(n==8){
     print 1;
    }
    else
    {
     print 0;
    }
}
