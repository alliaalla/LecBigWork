int main(int n) {
    
    return g(n,n);
}
void g(int m,int o){
    return 3;
}
