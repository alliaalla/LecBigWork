void main(){
    int a[4];
    a[0]=3;
    print a[4];
}