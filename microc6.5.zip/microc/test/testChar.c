void main(int n) {
    char a;
    a = 3;
    print a;
 }