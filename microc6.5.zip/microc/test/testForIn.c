//for-in-range函数
void main(){
  int i;
  for(i in range(10,5,-1)){
    print i;
  }
}
