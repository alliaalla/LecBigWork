void main(){
    int a;
    int b;
    a=1;
    b=0;
    print a&&b;
    print a||b;
}