//for语句
void main() {
  int i;
  for(i=0;i<4;i++){
    print i;
  }
}
