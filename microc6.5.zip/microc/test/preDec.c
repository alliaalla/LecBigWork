//前置自减
void main() {
  int x;
  x = 3;
  print --x;
  
  int a[3];
  a[0] = 1;
  a[1] = 2;
  a[2] = 3;
  print --a[2];
}