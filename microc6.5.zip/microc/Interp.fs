(* File MicroC/Interp.c
   Interpreter for micro-C, a fraction of the C language
   sestoft@itu.dk * 2010-01-07, 2014-10-18

   A value is an integer; it may represent an integer or a pointer,
   where a pointer is just an address in the store (of a variable or
   pointer or the base address of an array).  The environment maps a
   variable to an address (location), and the store maps a location to
   an integer.  This freely permits pointer arithmetics, as in real C.
   Expressions can have side effects.  A function takes a list of
   typed arguments and may optionally return a result.

   For now, arrays can be one-dimensional only.  For simplicity, we
   represent an array as a variable which holds the address of the
   first array element.  This is consistent with the way array-type
   parameters are handled in C (and the way that array-type variables
   were handled in the B language), but not with the way array-type
   variables are handled in C.

   The store behaves as a stack, so all data are stack allocated:
   variables, function parameters and arrays.

   The return statement is not implemented (for simplicity), so all
   functions should have return type void.  But there is as yet no
   typecheck, so be careful.
 *)

module Interp

open Absyn
open Debug

(* Simple environment operations *)
// 多态类型 env
// 环境 env 是 元组 ("name",data) 的列表 ，名称是字符串 string 值 'data 可以是任意类型
//  名称 ---> 数据 名称与数据绑定关系的 键-值 对  key-value pairs
// [("x",9);("y",8)]: int env

type 'data env = (string * 'data) list

//环境查找函数
//在环境 env上查找名称为 x 的值
let rec lookup env x =
    match env with
    | [] -> failwith (x + " not found")
    | (y, v) :: yr -> if x = y then v else lookup yr x

(* A local variable environment also knows the next unused store location *)

// ([("x",9);("y",8)],10)
// x 在位置9,y在位置8,10--->下一个空闲空间位置10
type locEnv = int env * int

(* A function environment maps a function name to parameter list and body *)
//函数参数例子:
//void func (int a , int *p)
// 参数声明列表为: [(TypI,"a");(TypP(TypI) ,"p")]
type paramdecs = (typ * string) list

(* 函数环境列表
  [("函数名", ([参数元组(类型,"名称")的列表],函数体AST)),....]

  //main (i){
  //  int r;
  //    fac (i, &r);
  //    print r;
  // }
  [ ("main",
   ([(TypI, "i")],
    Block
      [Dec (TypI,"r");
       Stmt (Expr (Call ("fac",[Access (AccVar "i"); Addr (AccVar "r")])));
       Stmt (Expr (Prim1 ("printi",Access (AccVar "r"))))]))]

函数环境 是 多态类型  'data env ---(string * 'data ) list 的一个 具体类型 ⭐⭐⭐
    类型变量 'data  具体化为  (paramdecs * stmt)
    (string * (paramdecs * stmt)) list
*)

type funEnv = (paramdecs * stmt) env

(* A global environment consists of a global variable environment
   and a global function environment
 *)

// 全局环境是 变量声明环境 和 函数声明环境的元组
// 两个列表的元组
// ([var declares...],[fun declares..])
// ( [ ("x" ,1); ("y",2) ], [("main",mainAST);("fac",facAST)] )
// mainAST,facAST 分别是main 与fac 的抽象语法树

type gloEnv = int env * funEnv

(* The store maps addresses (ints) to values (ints): *)

//地址是store上的的索引值
type address = int

// store 是一个 地址到值的映射，是对内存的抽象 ⭐⭐⭐
// store 是可更改的数据结构，特定位置的值可以修改，注意与环境的区别
// map{(0,3);(1,8) }
// 位置 0 保存了值 3
// 位置 1 保存了值 8

type store = Map<address, int>

//空存储
let emptyStore = Map.empty<address, int>

//保存value到存储store
let setSto (store: store) addr value = store.Add(addr, value)

//输入addr 返回存储的值value
let getSto (store: store) addr = store.Item addr

// store上从loc开始分配n个值的空间
// 用于数组分配
let rec initSto loc n store =
    if n = 0 then
        store
    else // 默认值 0
        initSto (loc + 1) (n - 1) (setSto store loc 0)

(* Combined environment and store operations *)

(* Extend local variable environment so it maps x to nextloc
   (the next store location) and set store[nextloc] = v.

locEnv结构是元组 : (绑定环境env,下一个空闲地址nextloc)
store结构是Map<string,int>

扩展环境 (x nextloc) :: env ====> 新环境 (env1,nextloc+1)
变更store (nextloc) = v
 *)

// 绑定一个值 x,v 到环境
// 环境是非更改数据结构，只添加新的绑定（变量名称，存储位置），注意与store 的区别⭐⭐⭐
// 返回新环境 locEnv,更新store,
// nextloc是store上下一个空闲位置
(*

// variable.c
int g ;
int h[3];
void main (int n){
n = 8;
}
上面c程序的解释环境如下：

 环境：locEnv:
    ([(n, 5); (n, 4); (g, 0)], 6)

存储：store:
    (0, 0)  (1, 0)(2, 0)(3, 0)(4, 1)  (5, 8)
     ^^^^    ^^^^^^^^^^^^^^^^^^^^^^    ^^^^
       g               h                n

   变量 地址 值
   n--->5--->8
   h--->4--->1
   g--->0--->0

   下一个待分配位置是 6
*)

//将多个值 xs vs绑定到环境
//遍历 xs vs 列表,然后调用 bindVar实现单个值的绑定
let store2str store =
    String.concat "" (List.map string (Map.toList store))

let bindVar x v (env, nextloc) store : locEnv * store =
    let env1 = (x, nextloc) :: env
    msg $"bindVar:\n%A{env1}\n"

    //返回新环境，新的待分配位置+1，设置当前存储位置为值 v
    let ret = ((env1, nextloc + 1), setSto store nextloc v)
    
    msg $"locEnv:\n {fst ret}\n"
    msg $"Store:\n {store2str (snd ret)}\n"

    ret 


let rec bindVars xs vs locEnv store : locEnv * store =
    let res =
        match (xs, vs) with
        | ([], []) -> (locEnv, store)
        | (x1 :: xr, v1 :: vr) ->
            let (locEnv1, sto1) = bindVar x1 v1 locEnv store
            bindVars xr vr locEnv1 sto1
        | _ -> failwith "parameter/argument mismatch"

    msg "\nbindVars:\n"
    msg $"\nlocEnv:\n{locEnv}\n"
    msg $"\nStore:\n"
    store2str store |> msg
    res
(* Allocate variable (int or pointer or array): extend environment so
   that it maps variable to next available store location, and
   initialize store location(s).
 *)
//

let rec allocate (typ, x) (env0, nextloc) sto0 : locEnv * store =

    let (nextloc1, v, sto1) =
        match typ with
        //数组 调用 initSto 分配 i 个空间
        | TypA (t, Some i) -> (nextloc + i, nextloc, initSto nextloc i sto0)
        // 常规变量默认值是 0
        | _ -> (nextloc, 0, sto0)

    msg $"\nalloc:\n {((typ, x), (env0, nextloc), sto0)}\n"
    bindVar x v (env0, nextloc1) sto1

(* Build global environment of variables and functions.  For global
   variables, store locations are reserved; for global functions, just
   add to global function environment.
*)

//初始化 解释器环境和store
let initEnvAndStore (topdecs: topdec list) : locEnv * funEnv * store =

    //包括全局函数和全局变量
    msg $"\ntopdecs:\n{topdecs}\n"

    let rec addv decs locEnv funEnv store =
        match decs with
        | [] -> (locEnv, funEnv, store)

        // 全局变量声明  调用allocate 在store上给变量分配空间
        | Vardec (typ, x) :: decr ->
            let (locEnv1, sto1) = allocate (typ, x) locEnv store
            addv decr locEnv1 funEnv sto1

        //全局函数 将声明(f,(xs,body))添加到全局函数环境 funEnv
        | Fundec (_, f, xs, body) :: decr -> addv decr locEnv ((f, (xs, body)) :: funEnv) store
        //全局变量初始化
        | VardecAndAssign (typ, x, expr) :: decr ->
            let (locEnv1, sto1) = allocate (typ, x) locEnv store //分配空间
            addv decr locEnv1 funEnv sto1
    // ([], 0) []  默认全局环境
    // locEnv ([],0) 变量环境 ，变量定义为空列表[],下一个空闲地址为0
    // ([("n", 1); ("r", 0)], 2)  表示定义了 变量 n , r 下一个可以用的变量索引是 2
    // funEnv []   函数环境，函数定义为空列表[]
    addv topdecs ([], 0) [] emptyStore

(* ------------------------------------------------------------------- *)

(* Interpreting micro-C statements *)

let rec exec stmt (locEnv: locEnv) (gloEnv: gloEnv) (store: store) : store =
    match stmt with
    | If (e, stmt1, stmt2) ->
        let (v, store1) = eval e locEnv gloEnv store

        if v <> 0 then
            exec stmt1 locEnv gloEnv store1 //True分支
        else
            exec stmt2 locEnv gloEnv store1 //False分支

    | While (e, body) ->

        //定义 While循环辅助函数 loop
        let rec loop store1 =
            //求值 循环条件,注意变更环境 store
            let (v, store2) = eval e locEnv gloEnv store1
            // 继续循环
            if v <> 0 then
                loop (exec body locEnv gloEnv store2)
            else
                store2 //退出循环返回 环境store2

        loop store

    | Expr e ->
        // _ 表示丢弃e的值,返回 变更后的环境store1
        let (_, store1) = eval e locEnv gloEnv store
        store1

    | Block stmts ->

        // 语句块 解释辅助函数 loop
        let rec loop ss (locEnv, store) =
            match ss with
            | [] -> store
            //语句块,解释 第1条语句s1
            // 调用loop 用变更后的环境 解释后面的语句 sr.
            | s1 :: sr -> loop sr (stmtordec s1 locEnv gloEnv store)

        loop stmts (locEnv, store)

    | Return _ -> failwith "return not implemented" // 解释器没有实现 return
    | For (e1, e2, e3, body) -> //for循环
        let (v1, store1) = eval e1 locEnv gloEnv store //计算初始化表达式的值，得到更新过的store1
        //定义while循环的辅助函数 loop【这里store是更新过的store1】
        let rec loop store1 =
                let (v2, store2) = eval e2 locEnv gloEnv store1 //计算循环条件的值

                if v2 <> 0 then // 如果循环条件不为0，就先执行函数体body，然后计算e3
                    let store3 = exec body locEnv gloEnv store2 //exec若是表达式的话，返回的就是一个更新过的store3
                    let (v3, store4) = eval e3 locEnv gloEnv store3 //计算表达式e3的值，返回更新过的store4
                    loop store4 //循环执行，传入的是store4
                else // 如果循环条件为0，退出循环，返回环境store2
                      store2
        loop store1 //循环执行
    | ForInExpr (acc,e1,e2, e3, body) -> //forin函数
            let (loc, store1) = access acc locEnv gloEnv store //取变量acc1的地址和环境
            let (v1, store2) = eval e1 locEnv gloEnv store1 //计算表达式e1，返回更新过的store2
            let (v2, store3) = eval e2 locEnv gloEnv store2 //计算表达式e2，返回更新过的store3
            let (v3, store4) = eval e3 locEnv gloEnv store3 //计算表达式e3，返回更新过的store4
            
            let rec loop i store5 = //i为步进值
                let store6 = exec body locEnv gloEnv (setSto store5 loc i)//每次刚进入循环就执行一遍函数体body

                //循环条件：当步进值为正，结束下标-(当前开始下标+步进值)大于0；当步进值为负，(当前开始下标+步进值)-结束下标大于0
                if (v2-(i+v3) > 0 && v1<v2 && v3>0) || (i+v3-v2 > 0 && v1>v2 && v3<0) then //如果循环条件大于0，表示还在循环中
                    loop (i+v3) store6 //循环执行，传入的是store5，步进值为 (旧步进值+v3)
                else //如果循环条件大于等于0，表示退出循环，返回环境store4
                    store6

            if (v1<v2 && v3>0) || (v1>v2 && v3<0) then //进入循环，变量的初值为v1，步进值为正或负
                loop v1 store4
            else //不满足初始循环条件，就返回store4
                store4
    | DoWhile (stmt1, e) -> //dowhile循环
        let store1=exec stmt1 locEnv gloEnv store//先执行一遍函数体body

        //定义dowhile循环的辅助函数 loop
        let rec loop store1 =
            //计算表达式e的值，返回更新过的store2
            let (v, store2) = eval e locEnv gloEnv store1
            // 继续循环
            if v <> 0 then
                loop (exec stmt1 locEnv gloEnv store2)
            // 退出循环，返回环境store2
            else
                store2

        loop store1
     | Switch (e,stmt1) -> //switchcase
        let (v,store1)=eval e locEnv gloEnv store//执行switch表达式

        //定义switch辅助函数body
        let rec body list = 
            match list with
            | Case(e2, stmt2) :: stmts -> //e2是常量表达式，stmt2是当前匹配的case语句，stmts是未匹配的case语句列表
                let (v2,store2)=eval e2 locEnv gloEnv store1//执行语句case语句中的表达式

                //和switch表达式进行比较
                if v = v2 then//匹配case语句的条件
                    exec stmt2 locEnv gloEnv store2//执行
                else//不匹配case语句的条件
                    body stmts//继续进行匹配

            | _ -> store1 //未匹配

        body stmt1
and stmtordec stmtordec locEnv gloEnv store =
    match stmtordec with
    | Stmt stmt -> (locEnv, exec stmt locEnv gloEnv store)
    | Dec (typ, x) -> allocate (typ, x) locEnv store
    | DecAndAssign (typ, x, expr) -> //局部变量初始化
            let (locEnv1 ,store1) = allocate (typ, x) locEnv store //调用allocate函数，
                                                                //为类型为typ的变量x在局部环境和store上分配空间，
                                                                //这里返回的locEnv1就是该变量的局部环境
            let (loc, store2) = access (AccVar x) locEnv1 gloEnv store1 //计算左值变量x的地址和更新过的store
            let (res, store3) = eval expr locEnv gloEnv store2 //计算表达式expr，返回值和更新过的store
            (locEnv1, setSto store3 loc res) //返回局部环境locEnv，把expr的值赋值给store3在loc位置上的变量，也就是赋值给变量x
(* Evaluating micro-C expressions *)

and eval e locEnv gloEnv store : int * store =
    match e with
    | Access acc ->
        let (loc, store1) = access acc locEnv gloEnv store
        (getSto store1 loc, store1)
    | Assign (acc, e) ->
        let (loc, store1) = access acc locEnv gloEnv store
        let (res, store2) = eval e locEnv gloEnv store1
        (res, setSto store2 loc res)
    | CstI i -> (i, store)
    | Addr acc -> access acc locEnv gloEnv store
    | Prim1 (ope, e1) -> //一元基本算子
        let (i1, store1) = eval e1 locEnv gloEnv store //在本地环境，全局环境中计算表达式e1的值

        let res =
            match ope with //模式匹配
            | "!" -> if i1 = 0 then 1 else 0 //取反
            | "printi" ->
                (printf "%d " i1
                 i1)
            | "printc" ->
                (printf "%c" (char i1)
                 i1)
            | _ -> failwith ("unknown primitive " + ope)

        (res, store1) //返回模式匹配计算到的值和存储
    | Prim2 (ope, e1, e2) -> //二元基本算子
        let (i1, store1) = eval e1 locEnv gloEnv store
        let (i2, store2) = eval e2 locEnv gloEnv store1

        let res =
            match ope with
            | "*" -> i1 * i2
            | "+" -> i1 + i2
            | "-" -> i1 - i2
            | "/" -> i1 / i2
            | "%" -> i1 % i2
            | "==" -> if i1 = i2 then 1 else 0
            | "!=" -> if i1 <> i2 then 1 else 0
            | "<" -> if i1 < i2 then 1 else 0
            | "<=" -> if i1 <= i2 then 1 else 0
            | ">=" -> if i1 >= i2 then 1 else 0
            | ">" -> if i1 > i2 then 1 else 0
            | _ -> failwith ("unknown primitive " + ope)

        (res, store2)
     | Prim3 (ope, acc, e) -> //复合赋值运算符
        let (loc, store1) = access acc locEnv gloEnv store //取要求的acc的地址和环境store1
        let v1=getSto store1 loc //得到acc地址上的值
        let (v2, store2) = eval e locEnv gloEnv store1 //计算表达式e的值，并得到新环境store2
        
        let res= //匹配五种复合赋值运算符，得到计算结果
            match ope with
            | "+=" -> v1 + v2
            | "-=" -> v1 - v2
            | "*=" -> v1 * v2
            | "/=" -> v1 / v2
            | "%=" -> v1 % v2
            | _ -> failwith ("unknown primitive " + ope)
        
        (res, setSto store2 loc res) //返回的store是把计算结果存到左值acc地址上后的新store
    | TernaryOperator (e1, e2, e3) -> //三目运算符
        let (v, store1) = eval e1 locEnv gloEnv store //计算表达式e1的值
        if v <> 0 then //表达式e1不为0
            let (v2, store2) = eval e2 locEnv gloEnv store1//计算e2
            (v2,store2) //返回结果和store2
        else //表达式e1为0
            let (v2, store2) = eval e3 locEnv gloEnv store1//计算e3
            (v2,store2) //返回结果和store2
    | PreInc acc -> //前置自增
        let (loc, store1) as res = access acc locEnv gloEnv store //取要求的acc的地址和环境
        let res = getSto store1 loc //得到要求的这个acc在store1的loc位置上的值
        (res + 1, setSto store1 loc (res + 1)) //把值加一后set到store中，元组左边返回的就是这个加一后的值
    | PreDec acc -> //前置自减
        let (loc, store1) as res = access acc locEnv gloEnv store //取要求的acc的地址和环境
        let res = getSto store1 loc //得到要求的这个acc在store1的loc位置上的值
        (res - 1, setSto store1 loc (res - 1)) //把值减一后set到store中，元组左边返回的就是这个减一后的值
    | NextInc acc -> //后置自增
        let (loc, store1) as res = access acc locEnv gloEnv store //取要求的acc的地址和环境
        let res = getSto store1 loc //得到要求的这个acc在store1的loc位置上的值
        (res, setSto store1 loc (res + 1)) //把值加一后set到store中，元组左边返回的是加一前自身的值
    | NextDec acc -> //后置自减
        let (loc, store1) as res = access acc locEnv gloEnv store //取要求的acc的地址和环境
        let res = getSto store1 loc //得到要求的这个acc在store1的loc位置上的值
        (res, setSto store1 loc (res - 1)) //把值减一后set到store中，元组左边返回的是减一前自身的值
    | Andalso (e1, e2) -> //e1&&e2
        let (i1, store1) as res = eval e1 locEnv gloEnv store //计算表达式e1的值和环境

        if i1 <> 0 then //表达式e1值不为0，根据||规则，结果就是res（即表达式e1的值<>0）
            eval e2 locEnv gloEnv store1
        else  //表达式e1值为0，根据&&规则，结果就是res（即表达式e1的值=0）
            res
    | Orelse (e1, e2) -> //e1||e2
        let (i1, store1) as res = eval e1 locEnv gloEnv store //计算表达式e1的值和环境

        if i1 <> 0 then //表达式e1值不为0，根据||规则，结果就是res（即表达式e1的值<>0）
            res
        else //表达式e1值为0，，就计算表达式e2的值和环境
            eval e2 locEnv gloEnv store1
    | Call (f, es) -> callfun f es locEnv gloEnv store

and access acc locEnv gloEnv store : int * store =
    match acc with
    | AccVar x -> (lookup (fst locEnv) x, store)
    | AccDeref e -> eval e locEnv gloEnv store
    | AccIndex (acc, idx) ->
        let (a, store1) = access acc locEnv gloEnv store
        let aval = getSto store1 a
        let (i, store2) = eval idx locEnv gloEnv store1
        (aval + i, store2)

and evals es locEnv gloEnv store : int list * store =
    match es with
    | [] -> ([], store)
    | e1 :: er ->
        let (v1, store1) = eval e1 locEnv gloEnv store
        let (vr, storer) = evals er locEnv gloEnv store1
        (v1 :: vr, storer)

and callfun f es locEnv gloEnv store : int * store =

    msg
    <| sprintf "callfun: %A\n" (f, locEnv, gloEnv, store)

    let (_, nextloc) = locEnv
    let (varEnv, funEnv) = gloEnv
    let (paramdecs, fBody) = lookup funEnv f
    let (vs, store1) = evals es locEnv gloEnv store

    let (fBodyEnv, store2) =
        bindVars (List.map snd paramdecs) vs (varEnv, nextloc) store1

    let store3 = exec fBody fBodyEnv gloEnv store2
    (-111, store3)

(* Interpret a complete micro-C program by initializing the store
   and global environments, then invoking its `main' function.
 *)

// run 返回的结果是 代表内存更改的 store 类型
// vs 参数列表 [8,2,...]
// 可以为空 []
let run (Prog topdecs) vs =
    //
    let ((varEnv, nextloc), funEnv, store0) = initEnvAndStore topdecs

    // mainParams 是 main 的参数列表
    //
    let (mainParams, mainBody) = lookup funEnv "main"

    let (mainBodyEnv, store1) =
        bindVars (List.map snd mainParams) vs (varEnv, nextloc) store0


    msg
    <|

    //以ex9.c为例子
    // main的 AST
    sprintf "\nmainBody:\n %A\n" mainBody
    +

    //局部环境
    // 如
    // i 存储在store位置0,store中下个空闲位置是1
    //([("i", 0)], 1)

    sprintf "\nmainBodyEnv:\n %A\n" mainBodyEnv
    +

    //全局环境 (变量,函数定义)
    // fac 的AST
    // main的 AST
    sprintf $"\n varEnv:\n {varEnv} \nfunEnv:\n{funEnv}\n"
    +

    //当前存储
    // store 中 0 号 位置存储值为8
    // map [(0, 8)]
    sprintf "\nstore1:\n %A\n" store1

    let endstore =
        exec mainBody mainBodyEnv (varEnv, funEnv) store1

    msg $"\nvarEnv:\n{varEnv}\n"
    msg $"\nStore:\n"
    msg <| store2str endstore

    endstore

(* Example programs are found in the files ex1.c, ex2.c, etc *)
